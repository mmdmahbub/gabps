<?php require_once("inc/header.php"); ?>

<!--============  Header Area End ==================-->

<!--============  Small Header Area start ==================-->
<?php require_once("inc/small_header.php"); ?>
<!--============  Samll header Area end ==================-->

<!--============  Gallery Area start ==================-->
<?php require_once("inc/gallery.php"); ?>
<!--============  Gallery Area end ==================-->

<?php require_once("inc/footer.php"); ?>