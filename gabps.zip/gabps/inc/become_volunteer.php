<div class="become_volunteer devider">
	<div class="container">
		<div class="col-md-8 col-md-offset-2">
			<div class="volunteer_text">
			<h1>become a volunteer</h1>
				<p>Eaque incidunt officiis harum ipsam rerum ipsame  dolore alias vel cumque dolores a velit in aliquam enim veritatis quis magni nstias placeat. </p>
				<a href="about.php" class="cta_btn">Join With Us</a>
			</div>
		</div>
	</div>
</div>