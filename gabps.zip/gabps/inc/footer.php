<!--============  Footer Area Start ==================-->

<footer class="footer_area">
	
	<div class="container" >
		<div class="row" style="position: relative">
			<div class="footer_contact_bar">
				<div class="footer_custom_col">
					<span class="footer_contact_icon"><i class="fa fa-map-marker"></i></span>
					<h5 >Temple ADDRESS</h5>
					<span> 506, Lorem Street, Station Road, <br /> New York, US 26355.</span>
				</div>
				<div class="footer_custom_col">
					<span class="footer_contact_icon"><i class="fa fa-phone"></i></span>
					<h5>Phone And Email</h5>
					<span> +1 ( 000 000 0000 ) <br /> info@gabps.com</span>
				</div>
				<div class="footer_custom_col">
					<span class="footer_contact_icon"><i class="fa fa-clock-o"></i></span>
					<h5>OPENING HOURS</h5>
					<span> Mon - Fri : 7:00 - 9:00 <br /> Sat - Sun : 8:00 - 11:00 </span>
				</div>
			</div>
		</div>
		<div class="row footer_content" >
			<div class="col-md-4">
				<h4 class="footer_header">Upcoming Events</h4>
				<a href="">
					<div class="single_events">
						<div class="events_thumb">
							<img src="public/img/logo.jpg" alt="" />
						</div>
						<div class="events_description">
							<h6>Events Name</h6>
							<span class="date_and_time"><i class="fa fa-calendar"></i> November 22 , 2018 </span>
							<span><i class="fa fa-map-marker"></i> November 22 , 2018</span>
							<br />
							<span class="date_and_time">
								<i class="fa fa-clock-o"></i> Tuesday - 8:00am
							</span>
							<span class="date_and_time">
								<i class="fa fa-ticket"></i> $324
							</span>
						</div>
					</div>
				</a>
				<a href="">
					<div class="single_events">
						<div class="events_thumb">
							<img src="public/img/logo.jpg" alt="" />
						</div>
						<div class="events_description">
							<h6>Events Name</h6>
							<span class="date_and_time"><i class="fa fa-calendar"></i> November 22 , 2018 </span>
							<span><i class="fa fa-map-marker"></i> November 22 , 2018</span>
							<br />
							<span class="date_and_time">
								<i class="fa fa-clock-o"></i> Tuesday - 8:00am
							</span>
							<span class="date_and_time">
								<i class="fa fa-ticket"></i> $324
							</span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-4">
				<h4 class="footer_header">Latest News</h4>
				<ul class="footer_nav">
					<li><a href="">Spiritual Disciplines for the hindu Life</a></li>
					<li><a href="">What Every Man Wishes His Father Had Told Him</a></li>
					<li><a href="">Spiritual Disciplines for the hindu Life</a></li>
					<li><a href="">What Every Man Wishes His Father Had Told Him</a></li>
					<li><a href="">Spiritual Disciplines for the hindu Life</a></li>
					<li><a href="">What Every Man Wishes His Father Had Told Him</a></li>
				</ul>
			</div>
			<div class="col-md-4">
				<h4 class="footer_header">recent photos</h4>
				<ul class="recent_photos">
					<li><a href=""><img src="public/img/logo.jpg" alt="" /></a></li>
					<li><a href=""><img src="public/img/logo.jpg" alt="" /></a></li>
					<li><a href=""><img src="public/img/logo.jpg" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
					<li><a href=""><img src="" alt="" /></a></li>
				</ul>
			</div>
		</div>
	</div>
	
</footer>
<div class="copyright">
	<div class="container">
		<div class="col-md-6">
			<span class="copy_text">
				Copyright &copy 2018, gabps. All Rights Reserved.
			</span>
		</div>
		<div class="col-md-6">
			<div class="footer_social_icon text-right">
				<a href=""><i class="fa fa-facebook"></i></a>
				<a href=""><i class="fa fa-twitter"></i></a>
				<a href=""><i class="fa fa-instagram"></i></a>
				<a href=""><i class="fa fa-pinterest"></i></a>
			</div>
		</div>
	</div>
</div>

<!--============  Footer Area End ==================-->
	<!-- Jquery v1.11.3 -->
	<script src="public/js/jquery.min.js"></script>
	<!-- Bootstrap Js -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<!-- magnific-popup JS -->
	<script  src="public/js/jquery.magnific-popup.min.js" ></script>
	<!-- Custom JS -->
	<script  src="public/js/custom.js" ></script>
</body>
</html>