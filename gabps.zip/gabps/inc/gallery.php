<div class="gallery_main devider">
	<div class="container">
		<div class="row">
			<div class="gallery_nav">
				<ul class="">
					<li class="filter-button active" data-filter="all">View All</li>
					<li class="filter-button" data-filter="gl">Charity</li>
					<li class="filter-button" data-filter="pj">Pujas</li>
					<li class="filter-button" data-filter="ev">Events</li>
				</ul>
			</div>
		</div>
				<div class="row">
			<div class="col-md-4 filter gl" >
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4 filter pj">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4 filter ev">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4 filter gl">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			
		</div>
	</div>
</div>