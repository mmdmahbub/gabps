<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>GABPS</title>
	<!-- Font-Awesome -->
	<link rel="stylesheet" href="public/css/font-awesome.min.css">
	<!-- Animate CSS -->
	<link rel="stylesheet" href="public/css/animate.css" />
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="public/css/bootstrap.min.css" />
	<link rel="stylesheet" href="public/css/magnific-popup.css" />
	<!--  Main stylesheet -->
	<link rel="stylesheet" href="public/css/style.css" />
	<!--  Responsive styesheet -->
	<link rel="stylesheet" href="public/css/responsive.css" />
	<!--  Source sans pro and satisfy Google fonts -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Satisfy" rel="stylesheet"> 
</head>
<body>
<!--============  Header Area Start ==================-->
<div class="temple_default_header">
	<div class="temple_top_nav">
		<div class="container">
			<div class="content_table">
				<div class="col-md-3 col-xs-12">
					<div class="temple_logo">
						<a href="#">
							<img src="public/img/logo.png" alt="logo" />
						</a>
					</div>
					<div class="in_mobile">
						<span class="cart_icon"><i class="fa fa-shopping-basket" ></i></span>
						<span class="mobile_menu"><i class="fa fa-bars" ></i></span>
					</div>
				</div>
				<div class="col-md-5 text-right col-md-offset-2 hide_in_mobile">
					<div class="col-md-4">
						<div class="contact_wrapper">
							<span class="temple_contact_info_icon"><i class="fa fa-phone" ></i></span>
							<span class="temple_contact_info_text">
								Call Us <br />
								1-000-000-0000
							</span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="contact_wrapper">
							<span class="temple_contact_info_icon"><i class="fa fa-envelope" ></i></span>
							<span class="temple_contact_info_text">
								Email Us <br />
								info@gabps.com
							</span>
						</div>
					</div>
					<div class="col-md-4" >
						<div class="contact_wrapper" >
							<span class="temple_contact_info_icon"><i class="fa fa-users" ></i></span>
							<span class="temple_contact_info_text social_icon">
								Follow Us <br />
								<a href=""><i class="fa fa-facebook"></i></a>
								<a href=""><i class="fa fa-twitter"></i></a>
								<a href=""><i class="fa fa-instagram"></i></a>
								<a href=""><i class="fa fa-pinterest"></i></a>
							</span>
						</div>
					</div>
				</div>
				<div class="col-md-2">
					<form action="" class="search" method="post">
						<input type="text" placeholder="Search here"/>
						<button type="submit" value=""/>
							<i class="fa fa-search"></i>
						</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<nav class="temple_main_nav">
		<div class="container">
			<ul class="mobile_version">
				<li><a href="index.php">Home</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="events.php">Events</a></li>
				<li><a href="">Shop</a></li>
				<li><a href="">About Us</a></li>
				<li><a href="">Contact US</a></li>
				<li class="pull-right"><a href=""> Donate Now <i class="fa fa-heart"></i> </a></li>
			</ul>
		</div>
	</nav>
</div>