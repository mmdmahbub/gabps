<div class="intro devider">
	<div class="container">
		<div class="col-md-6">
			<div class="intro_text">
				<div class="intro_header">
					<h1>Living Hope For <br />
					Real People </h1>
					<p>
						Eaque incidunt officiis harum ipsam rerum ipsame  dolore alias vel cumque dolores a velit in aliquam enim veritatis quis magni nstias placeat. 
					</p>
				</div>
				<div class="intro_content">
					<div class="single_content">
						<div class="intro_content_icon"><i class="fa fa-heart-o"></i></div>
						<div class="intro_content_desc">
							<h4>Building Holy and Healthy Lives</h4>
							<p>Vitae optio distinctio necessitatibus earum facere magni natus eaque consectetur, esse corporis dolore ostrum ullam. </p>
						</div>
					</div>
					<div class="single_content">
						<div class="intro_content_icon"><i class="fa fa-bell-o"></i></div>
						<div class="intro_content_desc">
							<h4>Experience God’s Presence</h4>
							<p>Vitae optio distinctio necessitatibus earum facere magni natus eaque consectetur, esse corporis dolore ostrum ullam. </p>
						</div>
					</div>
					<div class="single_content">
						<div class="intro_content_icon"><i class="fa fa-book"></i></div>
						<div class="intro_content_desc">
							<h4>Guidance in a Misguided World</h4>
							<p>Vitae optio distinctio necessitatibus earum facere magni natus eaque consectetur, esse corporis dolore ostrum ullam. </p>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		<div class="col-md-6">
			<div class="intro_img">
				<img src="public/img/home-welcome.png" alt="" />
			</div>
		</div>
	</div>
</div>