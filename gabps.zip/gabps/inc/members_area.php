<div class="members_area devider">
	<div class="container">
		<div class="row">
			<div class="members_header">
				<h1>Meet Our Gurus </h1>
				<p>Eaque incidu harum ipsam rerum </p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<div class="single_members">
					<div class="members_img">
						<img src="public/img/mem_1.jpg" alt="" />
					</div>
					<div class="members_details">
						<h1>Andrew Wills</h1>
						<p class="lead_guru">Lead Pastor</p>
						<p class="gurus_desc">Curabitur non erat ut orci malesuada egestas fusce eget ex massa bauris egestas lectus et dui laoreet euismod senec varius leo etiam porttitor velit orci at dictum lectus.</p>
						<div class="members_social_icon">
							<a href=""><i class="fa fa-facebook"></i></a>
							<a href=""><i class="fa fa-twitter"></i></a>
							<a href=""><i class="fa fa-instagram"></i></a>
							<a href=""><i class="fa fa-pinterest"></i></a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="single_members">
					<div class="members_img">
						<img src="public/img/mem_1.jpg" alt="" />
					</div>
					<div class="members_details">
						<h1>Andrew Wills</h1>
						<p class="lead_guru">Lead Pastor</p>
						<p class="gurus_desc">Curabitur non erat ut orci malesuada egestas fusce eget ex massa bauris egestas lectus et dui laoreet euismod senec varius leo etiam porttitor velit orci at dictum lectus.</p>
						<div class="members_social_icon">
							<a href=""><i class="fa fa-facebook"></i></a>
							<a href=""><i class="fa fa-twitter"></i></a>
							<a href=""><i class="fa fa-instagram"></i></a>
							<a href=""><i class="fa fa-pinterest"></i></a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="single_members">
					<div class="members_img">
						<img src="public/img/mem_1.jpg" alt="" />
					</div>
					<div class="members_details">
						<h1>Andrew Wills</h1>
						<p class="lead_guru">Lead Pastor</p>
						<p class="gurus_desc">Curabitur non erat ut orci malesuada egestas fusce eget ex massa bauris egestas lectus et dui laoreet euismod senec varius leo etiam porttitor velit orci at dictum lectus.</p>
						<div class="members_social_icon">
							<a href=""><i class="fa fa-facebook"></i></a>
							<a href=""><i class="fa fa-twitter"></i></a>
							<a href=""><i class="fa fa-instagram"></i></a>
							<a href=""><i class="fa fa-pinterest"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>