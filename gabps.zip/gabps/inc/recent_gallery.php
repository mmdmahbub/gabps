
<!--  recent_gallery Area start  -->
<div class="recent_gallery devider ">
	<div class="container">
		<div class="row">
			<div class="members_header">
				<h1>Recent Gallery </h1>
				<p>Eaque incidu harum ipsam rerum </p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sing_thumb  gellery-lightbox " >
					<a title="" class="gellary" href="public/img/g1.jpg">
						<img src="public/img/g1.jpg" alt="Gallery" />
						<div class="hrv_card">
							<i class="fa fa-search"></i>
						</div>
					</a>
				</div>
			</div>
			
		</div>
		<div class="row text-center" style="margin: 50px 0px">
			<a href="about.php" class="cta_btn glr" style="background: #333">View Our Gallery</a>
		</div>
	</div>
</div>
<!--  recent_gallery   end -->