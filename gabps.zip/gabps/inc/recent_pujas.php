<div class="recent_pujas devider">
	<div class="pujas_header">
		<div class="container">
			<h1>Recent Events </h1>
			<p>Eaque incidu harum ipsam rerum </p>
		</div>
	</div>
	<div class="pujas_body">
		<div class="container">
			<div class="row single_puja">
				<div class="col-md-5">
					<div class="pujas_date_and_link">
						<div class="pujas_date">
							<span class="date">27</span> 
							<div class="date_and_month">
								<span class="month">Aug</span>
								<span class="year">2017</span>
							</div>
						</div>
						<div class="pujas_links">
							<a href=""><i class="fa fa-play" ></i></a>
							<a href=""><i class="fa fa-headphones"></i></a>
							<a href=""><i class="fa fa-book"></i></a>
						</div>
					</div>
					<div class="pujas_thumb" style="background-image:url('./public/img/large.jpg'); ">
					</div>
				</div>
				<div class="col-md-7">
					<div class="pujas_content">
						<h3><a href="">Celebrating Our New Identity</a></h3>
						<h6>Speaker: <a href=""><span>John Doe</span></a> / Comments: <a href=""><span>0</span></a></h6>
						<p>Duis consectetur pretium nulla ac porta enim porttitor sllam porta purus justo lacinia aesd iaculis dolor var eget scelerisq alesuada fames ac ante ipsum primis in faucibus.</p>
						<a href="about.php" class="cta_btn">Learn More</a>
					</div>
				</div>
			</div>
			<div class="row single_puja">
				<div class="col-md-5">
					<div class="pujas_date_and_link">
						<div class="pujas_date">
							<span class="date">27</span> 
							<div class="date_and_month">
								<span class="month">Aug</span>
								<span class="year">2017</span>
							</div>
						</div>
						<div class="pujas_links">
							<a href=""><i class="fa fa-play" ></i></a>
							<a href=""><i class="fa fa-headphones"></i></a>
							<a href=""><i class="fa fa-book"></i></a>
						</div>
					</div>
					<div class="pujas_thumb" style="background-image:url('./public/img/large.jpg'); ">
					</div>
				</div>
				<div class="col-md-7">
					<div class="pujas_content">
						<h3><a href="">The Greatest Rescue Mission Ever</a></h3>
						<h6>Speaker: <a href=""><span>John Doe</span></a> / Comments: <a href=""><span>0</span></a></h6>
						<p>Duis consectetur pretium nulla ac porta enim porttitor sllam porta purus justo lacinia aesd iaculis dolor var eget scelerisq alesuada fames ac ante ipsum primis in faucibus.</p>
						<a href="about.php" class="cta_btn">Learn More</a>
					</div>
				</div>
			</div>
			<div class="row single_puja">
				<div class="col-md-5">
					<div class="pujas_date_and_link">
						<div class="pujas_date">
							<span class="date">27</span> 
							<div class="date_and_month">
								<span class="month">Aug</span>
								<span class="year">2017</span>
							</div>
						</div>
						<div class="pujas_links">
							<a href=""><i class="fa fa-play" ></i></a>
							<a href=""><i class="fa fa-headphones"></i></a>
							<a href=""><i class="fa fa-book"></i></a>
						</div>
					</div>
					<div class="pujas_thumb" style="background-image:url('./public/img/large.jpg'); ">
					</div>
				</div>
				<div class="col-md-7">
					<div class="pujas_content">
						<h3><a href="">The Fields Are Ripe for Harvest</a></h3>
						<h6>Speaker: <a href=""><span>John Doe</span></a> / Comments: <a href=""><span>0</span></a></h6>
						<p>Duis consectetur pretium nulla ac porta enim porttitor sllam porta purus justo lacinia aesd iaculis dolor var eget scelerisq alesuada fames ac ante ipsum primis in faucibus.</p>
						<a href="about.php" class="cta_btn">Learn More</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>