<div class="second_intro devider">
	<div class="container">
		<div class="col-md-6 col-md-offset-6">
			<div class="second_intro_right">
				<div class="second_intro_header">
					<h1>We Love God <br />
					We Believe in God</h1>
					<p>
						Eaque incidunt officiis harum ipsam rerum ipsame  dolore alias vel cumque dolores a velit in aliquam enim veritatis quis magni nstias Vestibulum acturpis  laci placeat. 
					</p>
					<a href="about.php" class="cta_btn">Join With Us</a>
				</div>
			</div>
		</div>
	</div>
</div>