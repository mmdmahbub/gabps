<!-- Slider Area start -->
<div class="slider devider">
	<div id="slide" class="carousel slide" data-ride="carousel" >
		<a class="left fawesome-control" href="#slide" role="button" data-slide="prev"><i class="fa fa-angle-right"></i></a>
		<a class="right fawesome-control" href="#slide" role="button" data-slide="next"><i class="fa fa-angle-left"></i></a>

		<div class="carousel-inner" role="listbox">
			<div class="item active">
				<div class="single_item bg_1" style="background: url('./public/img/wp1937532.jpg');background-repeat: no-repeat;background-position: center center;background-size: cover;position: relative;">
					<div class="overlay"></div>
					<div class="display_table">
						<div class="display_table_cell">
							<div class="container">
								<div class="slide_text text-center">
									<p class="more_text">More text here </p>
									<h2 class="animated fadeInDown">The standard chunk of Lorem Ipsum </h2>
									<p class="animated fadeInUp desc_text">There are many variations of passages</p>
									<a href="about.php" class="cta_btn">Learn More</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item ">
				<div class="single_item bg_1" style="background: url('./public/img/wp1937532.jpg');background-repeat: no-repeat;background-position: center center;background-size: cover;position: relative;">
					<div class="overlay"></div>
					<div class="display_table">
						<div class="display_table_cell">
							<div class="container">
								<div class="slide_text text-center">
									<p class="more_text">More text here 2 </p>
									<h2 class="animated fadeInDown">The standard chunk of Lorem Ipsum </h2>
									<p class="animated fadeInUp desc_text">There are many variations of passages</p>
									<a href="about.php" class="cta_btn">Learn More</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item ">
				<div class="single_item bg_1" style="background: url('./public/img/wp1937532.jpg');background-repeat: no-repeat;background-position: center center;background-size: cover;position: relative;">
					<div class="overlay"></div>
					<div class="display_table">
						<div class="display_table_cell">
							<div class="container">
								<div class="slide_text text-center">
									<p class="more_text">More text here 3</p>
									<h2 class="animated fadeInDown">The standard chunk of Lorem Ipsum </h2>
									<p class="animated fadeInUp desc_text">There are many variations of passages</p>
									<a href="about.php" class="cta_btn">Learn More</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Slider Area start -->