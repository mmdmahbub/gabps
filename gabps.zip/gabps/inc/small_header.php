<div class="small_header devider">
	<div class="container">
		<span class="sub_header_title">Gallery</span>
		<span class="paginate"><a href="">Home</a> <i class="fa fa-angle-right"></i> Gallery</span>
	</div>
</div>