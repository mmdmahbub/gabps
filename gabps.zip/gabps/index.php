<?php require_once("inc/header.php"); ?>

<!--============  Header Area End ==================-->

<!--============  Slider Area start ==================-->
<?php require_once("inc/slider.php"); ?>
<!--============  Slider Area end ==================-->

<!--============  intro Area start ==================-->
<?php require_once("inc/intro.php"); ?>
<!--============  intro Area end ==================-->

<!--============  2nd intro Area start ==================-->
<?php require_once("inc/second_intro.php"); ?>
<!--============  2nd intro Area end ==================-->

<!--============  2nd intro Area start ==================-->
<?php require_once("inc/second_intro.php"); ?>
<!--============  2nd intro Area end ==================-->

<!--============  recent pujas Area start ==================-->
<?php require_once("inc/recent_pujas.php"); ?>
<!--============  recent pujas Area end ==================-->

<!--============  recent pujas Area start ==================-->
<?php require_once("inc/become_volunteer.php"); ?>
<!--============  recent pujas Area end ==================-->

<!--============  recent pujas Area start ==================-->
<?php require_once("inc/members_area.php"); ?>
<!--============  recent pujas Area end ==================-->

<!--============  recent pujas Area start ==================-->
<?php require_once("inc/recent_gallery.php"); ?>
<!--============  recent pujas Area end ==================-->

<?php require_once("inc/footer.php"); ?>