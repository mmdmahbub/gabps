
//Magic Popup Image gallery 
$(document).ready(function(){
	$(".gellary").magnificPopup({
	  type: 'image',
	  gallery: {
		  enabled: true
	  }
    });
	$(".mobile_menu").click(function(){
		$(".mobile_version").toggleClass("show");
	});
  
});
//Sticky navbar script
$(window).scroll(function() {
	if ($(this).scrollTop() > 1){  
	$('.temple_main_nav').addClass("sticky");
	}
	else{
	$('.temple_main_nav').removeClass("sticky");
	}
});


$(document).ready(function(){

    $(".filter-button").click(function(){
		$('.gallery_nav li').click(function(){
			$('.gallery_nav li').removeClass("active");
			$(this).addClass("active");
		});
        var value = $(this).attr('data-filter');
        
        if(value == "all")
        {
            //$('.filter').removeClass('hidden');
            $('.filter').show('1000');
        }
        else
        {
//            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
//            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
            $(".filter").not('.'+value).hide('3000');
            $('.filter').filter('.'+value).show('3000');
            
        }
    });
    
    if ($(".filter-button").removeClass("active")) {
$(this).removeClass("active");
}
$(this).addClass("active");

});